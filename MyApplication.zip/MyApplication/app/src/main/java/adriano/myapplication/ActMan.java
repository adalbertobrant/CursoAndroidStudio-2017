package adriano.myapplication;


import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

public class ActMan extends Activity{

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_man);
    }
}
